import json
from pathlib import Path
import subprocess
import sys
from infra import OUT, ROOT, write

if __name__ == "__main__":
    label, script, *args=sys.argv[1:]
    assert label.replace("-","").isalnum()
    spec=OUT/(label+"-spec.json")
    write(spec,{"argv":[sys.executable,"-u",str(OUT/script),*args],"cwd":str(ROOT),"timeout_seconds":2300})
    completed=subprocess.run([sys.executable,str(Path.home()/".codex/tools/job_runner.py"),"run","--spec",str(spec),"--job-dir",str(OUT/(label+"-job"))],cwd=ROOT)
    status=json.loads((OUT/(label+"-job")/"status.json").read_text(encoding="utf-8"))
    if completed.returncode:
        raise SystemExit(status.get("exit_code") or 1)
