"""Task-owned local PostgreSQL/Qdrant/Redis, scoped workers, APIs and credentials."""
import argparse
from collections import Counter
from contextlib import ExitStack, contextmanager
import hashlib
import json
import os
from pathlib import Path
import socket
import subprocess
import sys
import time
import unicodedata

from dotenv import dotenv_values
import httpx

from infra import OUT, ROOT, configure

SRC = OUT / "source"
PUBLIC = ROOT / "benchmarks/public_rag/results/published/refusal-consistency-20261114"
PRIOR = PUBLIC.parent / "evidence-retention-20261114"
TRAIN = ROOT / "data/external/rag-public-20261021/qasper/extracted/qasper-train-v0.3.json"
LOGIN = OUT / "private-login.json"
STATE = OUT / "state.json"
COLLECTIONS = {
    "independent": "refusal_independent_50", "historical": "refusal_historical_16",
    "historical_vietnam": "refusal_historical_48",
}
COUNT = {"independent": 50, "historical": 16, "historical_vietnam": 48}
sys.path.insert(0, str(SRC))
configure()

from benchmarks.public_rag.article_live_capture import write
from benchmarks.public_rag.evidence_retention_replay import upload
from benchmarks.public_rag.qa_first_response_cases import paper_text, read
from scripts.aliyun_api_smoke import aliyun_route, create_provider_credential, request
from scripts.citation_qa_profile import create_qa_profile
from scripts.support_api_smoke import authenticate, register, retire_credential


def sha(value):
    return hashlib.sha256(value).hexdigest()


def lf(path):
    return sha(path.read_text(encoding="utf-8").encode())


def child(stack, args, label):
    logfile = stack.enter_context((OUT / (label + ".log")).open("xb"))
    proc = subprocess.Popen(
        [sys.executable, *args], cwd=SRC, stdout=logfile, stderr=logfile,
        env={**os.environ, "PYTHONPATH": str(SRC)}, stdin=subprocess.DEVNULL,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )
    def stop():
        if proc.poll() is None:
            proc.terminate()
        try:
            proc.wait(timeout=20)
        except subprocess.TimeoutExpired:
            proc.kill()
            proc.wait()
    stack.callback(stop)
    return proc


@contextmanager
def server(scope, label, *, worker=False, instrument=False):
    os.environ.update(
        AGENTHUB_KNOWLEDGE_QDRANT_COLLECTION=COLLECTIONS[scope],
        AGENTHUB_KNOWLEDGE_EMBEDDING_DEVICE="cuda",
        AGENTHUB_KNOWLEDGE_RERANKER_DEVICE="cuda",
        AGENTHUB_KNOWLEDGE_WARM_MODELS_ON_START="false",
        AGENTHUB_LANGFUSE_ENABLED="false",
    )
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        port = sock.getsockname()[1]
    with ExitStack() as stack:
        procs = []
        if worker:
            procs.append(child(stack, ["-m", "celery", "-A", "apps.worker.celery_app", "worker",
                "--pool=solo", "--concurrency=1", "--loglevel=WARNING",
                "--hostname", "refusal-consistency@%h"], label + "-worker"))
        if instrument:
            args = ["-m", "benchmarks.public_rag.refusal_consistency_live_trace",
                    "--port", str(port), "--events", str(OUT / (label + "-events.jsonl")),
                    "--candidate", str(OUT / "candidate" / "citation_qa.py"), "--freeze",
                    str(PUBLIC / "execution-freeze.json")]
        else:
            args = ["-m", "uvicorn", "apps.api.main:app", "--host", "127.0.0.1",
                    "--port", str(port), "--no-access-log"]
        procs.append(child(stack, args, label + "-api"))
        client = stack.enter_context(httpx.Client(base_url=f"http://127.0.0.1:{port}/api/v1/",
                                                   timeout=300, trust_env=False))
        start = time.monotonic()
        while True:
            if any(p.poll() is not None for p in procs):
                raise RuntimeError(f"Loopback service exited on startup: {label}")
            try:
                if client.get("ready").is_success:
                    break
            except httpx.ConnectError:
                pass
            if time.monotonic() - start > 150:
                raise TimeoutError(f"Loopback API unavailable: {label}")
            time.sleep(.5)
        yield client


def provision():
    if STATE.exists() or LOGIN.exists():
        raise RuntimeError("Workspace already created")
    # Keep provider credentials in the control process and its new encrypted workspace only.
    route_env = dotenv_values(ROOT / ".env", encoding="utf-8-sig")
    keys = ("AGENTHUB_RAG_API_KEY", "AGENTHUB_RAG_BASE_URL")
    for key in keys:
        if key not in os.environ and route_env.get(key):
            os.environ[key] = route_env[key]
    route = aliyun_route()
    for key in keys:
        os.environ.pop(key, None)
    assert (route.max_tokens, float(route.temperature), float(route.timeout_seconds)) == (2048, 0, 60)
    with server("historical", "provision") as client:
        _, owner = register(client)
        write(LOGIN, owner)
        org = request(client, "POST", "organizations", {"name": "Refusal consistency DEV"})
        workspace = request(client, "POST", "workspaces", {
            "name": "QASPER paired first responses", "organization_id": org["id"]})["id"]
        ws = "workspaces/" + workspace
        state = {"workspace": workspace, "credential": None, "datasets": {}}
        write(STATE, state)
        state["credential"] = create_provider_credential(client, ws, route)
        write(STATE, state)
        profile_id = create_qa_profile(client, ws, route, state["credential"], output_allowance=2048)
        profile = next(p for p in request(client, "GET", ws + "/model-profiles") if p["id"] == profile_id)
        assert (profile["model"], profile["max_tokens"], float(profile["temperature"]),
                float(profile["timeout_seconds"])) == (route.model, 2048, 0, 60)
        state.update(model=route.model, profile=profile_id, timeout_seconds=60, max_tokens=2048,
                     temperature=0)
        write(STATE, state)


def prepare_scope(scope):
    state = read(STATE)
    if scope in state["datasets"]:
        raise RuntimeError("Refusing duplicate upload")
    old = read(PRIOR / "protocol.json")
    if sha(TRAIN.read_bytes()) != old["train_sha256"]:
        raise ValueError("Official corpus differs from baseline")
    papers = read(TRAIN)
    if scope == "independent":
        paper_ids = read(PUBLIC / "protocol.json")["corpora"][scope]
    else:
        paper_ids = old["corpora"]["historical" if scope == "historical" else "independent"]
    assert len(set(paper_ids)) == len(paper_ids) == COUNT[scope]
    with server(scope, "ingest-" + scope, worker=True) as client:
        upload(client, read(LOGIN), state, scope, paper_ids, papers, OUT)
    mapping = read(OUT / f"{scope}-chunks.json")
    counts = Counter(c["source_id"] for c in mapping.values())
    ids = {c["source_id"]: (c["document_id"],c["revision"]) for c in mapping.values()}
    docs = {}
    for key in paper_ids:
        text = paper_text(papers[key])
        norm = unicodedata.normalize("NFC", text.replace("\r\n", "\n").replace("\r", "\n")).strip()
        doc, rev = ids[key]
        docs[key] = dict(document_id=doc, revision=rev, chunks=counts[key], paper_text_sha256=sha(text.encode()),
                         normalized_sha256=sha(norm.encode()))
    manifest = state["datasets"][scope]
    manifest.update(collection=COLLECTIONS[scope], embedding_device="cuda", documents=docs)
    if scope != "independent":
        reference = read(PRIOR / "snapshots" / ("historical.json" if scope == "historical" else "independent.json"))
        for key, current in docs.items():
            assert all(current[k] == reference["documents"][key][k] for k in ("chunks","paper_text_sha256","normalized_sha256"))
        assert len(docs) == reference["count"] and manifest["chunks"] == reference["chunks"]
    write(STATE, state)
    (PUBLIC / "snapshots").mkdir(exist_ok=True, parents=True)
    write(PUBLIC / "snapshots" / f"{scope}.json", manifest)
    print(json.dumps({"scope": scope, "papers": len(docs), "chunks": len(mapping)}))


def retire():
    owner = read(LOGIN)
    state = read(STATE)
    with server("historical","retire") as client:
        authenticate(client, owner)
        outcome = retire_credential(client, owner, f"workspaces/{state['workspace']}/provider-credentials",
                                    state["credential"], "Smoke")
        write(OUT / "retirement.json", outcome)
        assert outcome["disable"]["confirmed"] and outcome["rotate"]["confirmed"]


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("action", choices=["provision", "prepare", "retire"])
    p.add_argument("--scope", choices=list(COLLECTIONS), default="historical")
    args = p.parse_args()
    if args.action == "provision":
        provision()
    elif args.action == "retire":
        retire()
    else:
        prepare_scope(args.scope)
