import argparse
import json
import os
from pathlib import Path
import secrets
import subprocess
import sys
from uuid import uuid4

from cryptography.fernet import Fernet

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[1]
SETTINGS = OUT / "private.env.json"
PORTS = OUT / "ports.json"


def write(path, data):
    path.write_text(json.dumps(data, indent=2) + "\n", encoding="utf-8")


def configure():
    private = json.loads(SETTINGS.read_text(encoding="utf-8"))
    endpoints = json.loads(PORTS.read_text(encoding="utf-8"))
    database = f"postgresql+asyncpg://ragtest:{private['db']}@{endpoints['db']}/agenthub_recall_test"
    for key, value in {
        "DATABASE_URL": database, "TEST_DATABASE_URL": database,
        "QDRANT_URL": "http://" + endpoints["vector"], "TEST_QDRANT_URL": "http://" + endpoints["vector"],
        "REDIS_URL": "redis://" + endpoints["redis"] + "/2", "TEST_REDIS_URL": "redis://" + endpoints["redis"] + "/2",
        "ENVIRONMENT": "local", "TESTING": "false", "AUTH_JWT_SECRET": private["jwt"],
        "CREDENTIAL_MASTER_KEY": private["cipher"], "BLOB_ROOT": str(OUT / "blobs"),
        "KNOWLEDGE_QDRANT_COLLECTION": "scifact_recall_live", "KNOWLEDGE_EMBEDDING_DEVICE": "cpu",
        "KNOWLEDGE_RERANKER_DEVICE": "cpu", "KNOWLEDGE_WARM_MODELS_ON_START": "false",
        "KNOWLEDGE_QDRANT_TIMEOUT_SECONDS": "120",
    }.items():
        os.environ["AGENTHUB_" + key] = value
    os.environ.update(HF_HOME=str(ROOT.parent / "hf_cache"), HF_HUB_CACHE=str(ROOT.parent / "hf_cache"),
                      HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1", LITELLM_LOCAL_MODEL_COST_MAP="True",
                      OMP_NUM_THREADS="3", MKL_NUM_THREADS="3", TOKENIZERS_PARALLELISM="false",
                      PYTHONUTF8="1", NO_COLOR="1")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=("up", "down", "migrate"))
    action = parser.parse_args().action
    if action == "migrate":
        configure()
        subprocess.run([sys.executable, "-m", "alembic", "upgrade", "head"], cwd=OUT / "source", check=True)
        return
    if action == "up" and not SETTINGS.exists():
        write(SETTINGS, {"project": "agenthubrefusal" + uuid4().hex[:10], "db": secrets.token_hex(24),
                         "jwt": secrets.token_urlsafe(55), "cipher": Fernet.generate_key().decode()})
    private = json.loads(SETTINGS.read_text(encoding="utf-8"))
    env = {**os.environ, "POSTGRES_PASSWORD": private["db"]}
    compose = ["docker", "compose", "-p", private["project"], "-f", str(OUT / "compose.yaml")]
    if action == "up":
        subprocess.run([*compose, "up", "-d", "--wait", "--wait-timeout", "100"], cwd=OUT, env=env, check=True)
        ports = {"project": private["project"]}
        for name, port in (("db", 5432), ("vector", 6333), ("redis", 6379)):
            binding = subprocess.check_output([*compose, "port", name, str(port)], env=env, text=True).strip()
            assert binding.startswith("127.0.0.1:")
            ports[name] = binding
        write(PORTS, ports)
        print(json.dumps(ports))
    else:
        filt=f"label=com.docker.compose.project={private['project']}"
        def docker_ids(*args):
            return set(subprocess.check_output(["docker",*args],text=True).splitlines())
        project_containers=docker_ids("ps","-aq","--filter",filt)
        other_containers=docker_ids("ps","-aq")-project_containers
        project_networks=docker_ids("network","ls","-q","--filter",filt)
        volumes=set()
        for cid in project_containers:
            mounts=json.loads(subprocess.check_output(["docker","inspect","--format","{{json .Mounts}}",cid],text=True))
            volumes.update(m["Name"] for m in mounts if m["Type"]=="volume")
        subprocess.run([*compose, "down", "--volumes", "--remove-orphans"], env=env, cwd=OUT, check=True)
        remaining = subprocess.check_output(["docker", "ps", "-aq", "--filter", f"label=com.docker.compose.project={private['project']}"], text=True).strip()
        remaining_labeled_volumes = subprocess.check_output(["docker","volume","ls","-q","--filter",f"label=com.docker.compose.project={private['project']}"], text=True).strip()
        networks = subprocess.check_output(["docker","network","ls","-q","--filter",f"label=com.docker.compose.project={private['project']}"], text=True).strip()
        assert not (remaining or remaining_labeled_volumes or networks)
        assert not volumes.intersection(docker_ids("volume","ls","-q"))
        assert other_containers==docker_ids("ps","-aq")
        remaining_running = len(docker_ids("ps","-q"))
        SETTINGS.unlink()
        (OUT / "private-login.json").unlink(missing_ok=True)
        (OUT / "private-login.json.tmp").unlink(missing_ok=True)
        PORTS.unlink()
        write(OUT / "cleanup.json", {"project": private["project"], "removed_containers":len(project_containers),
                                     "removed_mounted_volumes":len(volumes),"removed_networks":len(project_networks),
                                     "remaining_containers":0,"remaining_mounted_volumes":0,
                                     "remaining_labeled_volumes":0,"remaining_networks":0,
                                     "unchanged_nonproject_container_ids":len(other_containers),
                                     "other_running_containers_after_project_cleanup":remaining_running,
                                     "private_env_file_and_ports_removed":True})


if __name__ == "__main__":
    main()
