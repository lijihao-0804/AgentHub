"""Freeze execution, preflight both frozen services, and collect independent HTTP responses."""
import hashlib
from datetime import UTC, datetime
from importlib.metadata import version
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys

from lifecycle import COLLECTIONS, OUT, PRIOR, PUBLIC, ROOT, SRC, STATE, TRAIN, lf, read, server, sha
from benchmarks.public_rag.article_live_capture import write

BASE = "46362e9245c7a708d015f1bd2a462d850cb0e118"
NEW = "393aa776eb18d469fe3f6d87df80534170e8cd48"
QA = "packages/knowledge/citation_qa.py"
RULE = "packages/knowledge/refusal_consistency.py"
EXPECTED = {"A": "49810477c78dbe3a0c1a6063b410b13eff0c62c15220a61957238f312cbc8e2c",
            "B": "e0ee46e9a70be9222d841483f3edf9d00b0ea5f4d27076953a9e0a440a5c4571",
            "rule": "4844051e09952eeeed804175da11e91e2e91532a3c2546994a68153cb1f6d3fa"}
PROTOCOL = PUBLIC / "protocol.json"
FREEZE = PUBLIC / "execution-freeze.json"
HARNESSES = ["benchmarks/public_rag/refusal_consistency_live.py", "benchmarks/public_rag/refusal_consistency_live_trace.py",
             "benchmarks/public_rag/evidence_retention_live.py"]


def sources():
    if FREEZE.exists():
        raise FileExistsError("Execution already frozen")
    (OUT / "candidate").mkdir(exist_ok=True)
    for repo_name, path in ((QA, OUT/"candidate/citation_qa.py"), (RULE, SRC/RULE)):
        data = subprocess.check_output(["git", "show", f"{NEW}:{repo_name}"], cwd=ROOT)
        assert sha(data) == EXPECTED["B" if repo_name == QA else "rule"]
        path.write_bytes(data)
    for name in HARNESSES:
        shutil.copyfile(ROOT / name, SRC / name)
    assert lf(SRC / QA) == EXPECTED["A"]
    from benchmarks.public_rag.refusal_consistency_live_trace import instrument
    from apps.api.main import app
    source_info = {"qa_source_sha256_lf":{k:EXPECTED[k] for k in ("A","B")},
                   "rule_sha256_lf":EXPECTED["rule"],
                   "source_sha256_lf":{k:lf(SRC/k) for k in HARNESSES}}
    instrument(app, OUT / "setup-only-never-written.jsonl", OUT / "candidate/citation_qa.py", source_info)
    # The setup-only process installs the trace once and terminates without sending a request.
    assert not (OUT/"setup-only-never-written.jsonl").exists()
    print(json.dumps(source_info))


def freeze():
    from benchmarks.public_rag.evidence_retention_live import PROFILE
    from packages.core.config.settings import Settings
    from packages.knowledge.citation_qa import _PROMPT_JSON_SYSTEM
    from packages.knowledge.adapters.reranker import BgeReranker
    import torch
    if FREEZE.exists():
        raise FileExistsError("Execution method already frozen")
    previous = read(PRIOR / "execution-freeze.json")
    state = read(STATE)
    protocol = read(PROTOCOL)
    assert set(state["datasets"]) == set(COLLECTIONS)
    for key, ds in state["datasets"].items():
        papers = protocol["corpora"][key]
        assert set(ds["documents"]) == set(papers)
        assert all(ds["documents"][p]["paper_text_sha256"] == protocol["rendered_paper_utf8_sha256"][p]
                   for p in papers)
    assert sha(TRAIN.read_bytes()) == protocol["train_sha256"]
    assert lf(PUBLIC / "acceptance.md") == protocol["acceptance_sha256_lf"]
    assert lf(PUBLIC / "rubric.md") == protocol["whole_answer_rubric_sha256_lf"]
    assert lf(PUBLIC / "exposure.json") == protocol["exposure_sha256_lf"]
    paths = dict.fromkeys([*previous["source"], *HARNESSES, RULE,
                          "packages/knowledge/adapters/sparse.py", "apps/api/knowledge_dependencies.py",
                          "benchmarks/public_rag/qa_first_response_budget.py"])
    mapping = {f: lf(SRC / f) for f in paths}
    for f in previous["source_sha256_lf"]:
        if f not in HARNESSES:
            assert mapping[f] == previous["source_sha256_lf"][f], f
    assert sha(_PROMPT_JSON_SYSTEM.encode()) == previous["reader_system_prompt_sha256"]
    settings = Settings()
    assert torch.cuda.is_available()
    models = {name:(ROOT.parent/"hf_cache"/("models--"+name.replace("/","--"))/"refs/main").read_text().strip()
              for name in (settings.knowledge_embedding_model, settings.knowledge_reranker_model)}
    assert models == previous["models"]
    assert set(mapping) and mapping[QA] == EXPECTED["A"] and mapping[RULE] == EXPECTED["rule"]
    assert lf(OUT / "candidate/citation_qa.py") == EXPECTED["B"]
    for n in HARNESSES:
        assert mapping[n] == lf(ROOT/n)
    code = {f:sha((SRC/f).read_bytes()) for f in paths}
    result = dict(
        protocol_sha256=sha(PROTOCOL.read_bytes()), protocol_sha256_lf=lf(PROTOCOL),
        frozen_utc=datetime.now(UTC).isoformat(), frozen_before_first_dispatch=True,
        baseline_commit=BASE, candidate_commit=NEW,
        qa_source_sha256_lf={k:EXPECTED[k] for k in ("A","B")}, rule_sha256_lf=EXPECTED["rule"],
        source=code, source_sha256_lf=mapping,
        operator_script_sha256_lf={f:lf(OUT/f) for f in ("measure.py","lifecycle.py","infra.py","job.py")}, 
        request_mode="provider_default", output_mode="PROMPT_JSON", retrieval_profile=PROFILE,
        reader_system_prompt_sha256=sha(_PROMPT_JSON_SYSTEM.encode()), scope_snapshots={
            s:{k:v for k,v in ds.items() if k!="documents"} for s, ds in state["datasets"].items()},
        **{k:state[k] for k in ("profile","model","max_tokens","timeout_seconds","temperature")},
        gpu=torch.cuda.get_device_name(0), models=models, device="cuda", reranker_precision="float16",
        reranker_max_input_tokens=BgeReranker.DEFAULT_MAX_LENGTH, evidence_chars_setting=settings.knowledge_qa_max_evidence_chars,
        torch=str(torch.__version__), cuda_runtime=str(torch.version.cuda), python=platform.python_version(),
        packages={k:version(k) for k in ["transformers","sentence-transformers","qdrant-client","litellm","openai"]},
        endpoint="POST /api/v1/knowledge/query", retrieval_arm="B", output_validation={"A":"baseline_commit unmodified",
            "B":"candidate_commit, verify_refusal_consistency=True"}, balanced_order=True,
        independent_first_http=100, historical_first_http=6,
        authorization="Separate first requests per arm, no retries of first requests; native internal citation correction counted",
    )
    for k in ("gpu","models","torch","cuda_runtime","packages","reranker_max_input_tokens","evidence_chars_setting",
              "temperature","max_tokens","timeout_seconds","model","retrieval_profile"):
        assert result[k] == previous[k], k
    write(FREEZE, result)
    print(json.dumps({"freeze":sha(FREEZE.read_bytes()), "protocol":lf(PROTOCOL), "gpu":result["gpu"],
                      "first_http":106}))


def run():
    from benchmarks.public_rag.refusal_consistency_live import run as requests
    frozen = read(FREEZE)
    if (any(lf(SRC/f) != h for f,h in frozen["source_sha256_lf"].items())
            or any(lf(OUT/f) != h for f,h in frozen["operator_script_sha256_lf"].items())):
        raise RuntimeError("Frozen executable source drift")
    state = read(STATE)
    for scope in COLLECTIONS:
        label = "live-" + scope
        trace = OUT / (label+"-events.jsonl")
        with server(scope, label, instrument=True) as client:
            requests(api=str(client.base_url), scope=scope, state_dir=OUT, protocol=PROTOCOL,
                     freeze=FREEZE, trace=trace, directory=OUT/"live", output=PUBLIC/"live")
        print(json.dumps({"scope":scope, "done":True}), flush=True)


if __name__ == "__main__":
    {"sources":sources, "freeze":freeze, "live":run}[sys.argv[1]]()
